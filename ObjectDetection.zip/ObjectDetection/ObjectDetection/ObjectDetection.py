import sys
import cv2
import numpy as np
import mss
import time
from PyQt5 import QtCore
from PyQt5.QtGui import QPixmap, QImage, QPainter
from PyQt5.QtWidgets import QLabel, QApplication, QMainWindow
from ultralytics import YOLO

# YOLOv8 model setup (small model for faster speed)
model = YOLO('yolov8n.pt')

# Screen capture using mss for real-time capture
def grab_screen(region=None):
    with mss.mss() as sct:
        monitor = sct.monitors[1]  # Capture the primary monitor
        if region:
            img = np.array(sct.grab(region))
        else:
            img = np.array(sct.grab(monitor))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)

# Convert YOLO boxes into transparent image
def create_transparent_overlay(image, results):
    # Create a transparent image
    overlay = np.zeros((image.shape[0], image.shape[1], 4), dtype=np.uint8)

    # Loop through YOLO results and draw bounding boxes on the transparent image
    for box in results[0].boxes:
        if int(box.cls) == 0:  # Only draw boxes for "person" class (class ID = 0)
            x1, y1, x2, y2 = map(int, box.xyxy[0])  # Get bounding box coordinates
            confidence = box.conf[0]  # Get confidence score

            # Draw bounding box (green with alpha channel)
            cv2.rectangle(overlay, (x1, y1), (x2, y2), (0, 255, 0, 255), 2)

            # Put the confidence score (label) above the bounding box
            label = f"person {confidence:.2f}"
            cv2.putText(overlay, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255, 255), 2)
    
    return overlay

# PyQt5 Window for Transparent Overlay
class OverlayWindow(QMainWindow):
    def __init__(self, screen_width, screen_height):
        super().__init__()
        self.label = QLabel(self)

        # Make window frameless, always on top, and transparent
        self.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint | QtCore.Qt.FramelessWindowHint | QtCore.Qt.Tool)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)  # Allow clicks to pass through

        # Set the window size to the screen size and position it at (0, 0)
        self.setGeometry(0, 0, screen_width, screen_height)

        # Make sure the window doesn't resize based on the content
        self.setFixedSize(screen_width, screen_height)

    def update_image(self, overlay):
        # Convert the OpenCV image to QImage with alpha channel
        qt_image = QImage(overlay.data, overlay.shape[1], overlay.shape[0], overlay.strides[0], QImage.Format_RGBA8888)
        pixmap = QPixmap.fromImage(qt_image)

        # Set the QPixmap to the label
        self.label.setPixmap(pixmap)
        # Update the label to fit the pixmap without resizing the window itself
        self.label.setGeometry(0, 0, self.width(), self.height())

# Main function to capture screen, run YOLOv8, and show results in overlay
def main():
    # Get screen resolution
    with mss.mss() as sct:
        monitor = sct.monitors[1]  # Capture the primary monitor
        screen_width = monitor["width"] - 100  # Subtract 100 from the width
        screen_height = monitor["height"] - 100  # Subtract 100 from the height

    # Set up PyQt5 application and overlay window
    app = QApplication(sys.argv)
    window = OverlayWindow(screen_width, screen_height)
    window.showFullScreen()  # Make the window full screen

    # Frame counter and FPS variables
    fps = 0
    start_time = time.time()

    # Main loop to capture and process frames smoothly
    while True:
        # Capture the screen with 100 pixels subtracted from width and height
        screen = grab_screen(region=(0, 40, screen_width, screen_height))

        # YOLOv8 object detection
        results = model(screen)  # Use the modified screen size for YOLO detection

        # Create transparent overlay with YOLO boxes
        overlay = create_transparent_overlay(screen, results)

        # Update the overlay window with detection results
        window.update_image(overlay)

        # Process PyQt5 events to keep the window responsive
        app.processEvents()

        # FPS calculation (optional for performance monitoring)
        fps += 1
        if (time.time() - start_time) >= 1:
            print(f"FPS: {fps}")
            fps = 0
            start_time = time.time()

# Run the main function
if __name__ == "__main__":
    main()